#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>

#include "dds.h"

static int is_speaking = 0;

static int dds_ev_ccb(void *userdata, struct dds_msg *msg) {
	int type;
	if (!dds_msg_get_type(msg, &type)) {
		switch (type) {
        case DDS_EV_OUT_DUI_RESPONSE:
        {
            char *resp = NULL;
            dds_msg_get_string(msg, "response", &resp);
            printf("dui response:%s", resp);
        }

		case DDS_EV_OUT_RECORD_AUDIO:
		{
			char data[3200];
			int n = fread(data, 1, 3200, (FILE*)userdata);
			if (n > 0) {
				struct dds_msg *m = dds_msg_new();
				dds_msg_set_type(m, DDS_EV_IN_AUDIO_STREAM);
				dds_msg_set_bin(m, "audio", data, n);
				dds_send(m);
				dds_msg_delete(m);
//				printf("...\n");
			}
		}
			break;
		case DDS_EV_OUT_STATUS:
		{
			char *value;
			if (!dds_msg_get_string(msg, "status", &value)) {
				printf("status: %s\n", value);
			}
		}
			break;
		case DDS_EV_OUT_NATIVE_CALL:
		{
			printf("DDS_EV_OUT_NATIVE_CALL\n");
			char *value;
			if (!dds_msg_get_string(msg, "api", &value)) {
				printf("api: %s\n", value);
			}

			if (!dds_msg_get_string(msg, "param", &value)) {
				printf("param: %s\n", value);
			}

			struct dds_msg *m = dds_msg_new();
			dds_msg_set_type(m, DDS_EV_IN_NATIVE_RESPONSE);
			dds_msg_set_string(m, "key1", "xxx");
			dds_send(m);
			dds_msg_delete(m);
		}
			break;
		case DDS_EV_OUT_COMMAND:
		{
			printf("DDS_EV_OUT_COMMAND\n");
			char *value;
			if (!dds_msg_get_string(msg, "api", &value)) {
				printf("api: %s\n", value);
			}

			if (!dds_msg_get_string(msg, "param", &value)) {
				printf("param: %s\n", value);
			}
		}
			break;
		case DDS_EV_OUT_TTS:
		{
			char *value;
			if (!dds_msg_get_string(msg, "speakUrl", &value)) {
				printf("speakUrl: %s\n", value);
				is_speaking = 1;
			}
		}
			break;
		case DDS_EV_OUT_ERROR:
		{
			char *value;
			if (!dds_msg_get_string(msg, "error", &value)) {
				printf("DDS_EV_OUT_ERROR: %s\n", value);
			}
		}
			break;
		case DDS_EV_OUT_ASR_RESULT:
		{
			char *value;
			if (!dds_msg_get_string(msg, "var", &value)) {
				printf("var: %s\n", value);
			}
            if (!dds_msg_get_string(msg, "text", &value)) {
				printf("text: %s\n", value);
			}
		}
			break;
		case DDS_EV_OUT_MEDIA:
		{
			char *value;
			if (!dds_msg_get_string(msg, "list", &value)) {
				printf("list: \n%s\n", value);
			}
		}
			break;
		default:
			break;
		}
	}
	return 0;
}

static void *speech_interact_routine(void* arg) {
    sleep(4);

#if defined USE_VAD
    /*
     * 发送唤醒事件，sdk 内部做vad
     */
    struct dds_msg *msg = dds_msg_new();
    dds_msg_set_type(msg, DDS_EV_IN_WAKEUP);
    dds_send(msg);
    printf("============= DDS_EV_IN_WAKEUP\n");
    dds_msg_delete(msg);
#else
    /*
     * 外部做vad，直接输入音频给 sdk
     */
	struct dds_msg *msg = dds_msg_new();
	dds_msg_set_type(msg, DDS_EV_IN_SPEECH);
	dds_msg_set_string(msg, "action", "start");
	dds_send(msg);
    printf("============= DDS_EV_IN_SPEECH start\n");
	dds_msg_delete(msg);

	sleep(6);

	msg = dds_msg_new();
	dds_msg_set_type(msg, DDS_EV_IN_SPEECH);
	dds_msg_set_string(msg, "action", "end");
	dds_send(msg);
    printf("============= DDS_EV_IN_SPEECH end\n");
	dds_msg_delete(msg);
#endif

	int cnt = 0;
	while (1) {
		cnt++;
		sleep(1);
		if (is_speaking) {
			msg = dds_msg_new();
			dds_msg_set_type(msg, DDS_EV_IN_PLAYER_STATUS);
			dds_msg_set_string(msg, "status", "end");
			dds_send(msg);
            printf("============= DDS_EV_IN_PLAYER_STATUS end\n");
			dds_msg_delete(msg);
			break;
		}
		if (cnt > 20) break;
	}

	sleep(3);

	msg = dds_msg_new();
	dds_msg_set_type(msg, DDS_EV_IN_EXIT);
    dds_send(msg);
    printf("============= DDS_EV_IN_EXIT\n");
    dds_msg_delete(msg);

	return NULL;
}


void main() {
    // 模拟音频输入
	FILE *f = fopen("./test.wav", "rb");
    assert(f);
	fseek(f, 44, SEEK_SET);

    // 模拟音频播放
	is_speaking = 0;

    // 启动模拟交互线程
	pthread_t tid;
	pthread_create(&tid, NULL, speech_interact_routine, NULL);

    // 读取配置，启动 dds sdk
    struct dds_msg *msg = dds_msg_new();
    dds_msg_set_string(msg, "productId", "100001306");
	dds_msg_set_string(msg, "aliasKey", "prod");
	dds_msg_set_string(msg, "deviceId", "001a11171152");
    dds_msg_set_string(msg, "vadResBin", "./xxx.bin");//vad资源
    dds_msg_set_string(msg, "deviceProfile", "xxx");//授权profile文件的内容


	struct dds_opt opt;
	opt._handler = dds_ev_ccb;
	opt.userdata = f;
	dds_start(msg, &opt); // 启动 sdk 线程
	dds_msg_delete(msg);

    pthread_join(tid, NULL);
    fclose(f);

    printf("============= main exit\n");
}


