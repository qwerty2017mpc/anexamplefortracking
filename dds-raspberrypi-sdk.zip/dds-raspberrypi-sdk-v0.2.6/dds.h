#ifndef __DDS_H__
#define __DDS_H__

#define DDS_VERSION     "DDS 0.2.6"
#define DDS_VERSION_NUM 206

/* callback event */
#define DDS_EV_OUT_RECORD_AUDIO                    1
#define DDS_EV_OUT_NATIVE_CALL                     2
#define DDS_EV_OUT_COMMAND                         3
#define DDS_EV_OUT_MEDIA                           4
#define DDS_EV_OUT_STATUS                          5
#define DDS_EV_OUT_TTS                             6
#define DDS_EV_OUT_ERROR                           7
#define DDS_EV_OUT_ASR_RESULT                      8
#define DDS_EV_OUT_DUI_RESPONSE                    9

/* external event */
#define DDS_EV_IN_SPEECH                           101
#define DDS_EV_IN_WAKEUP                           102
#define DDS_EV_IN_NATIVE_RESPONSE                  103
#define DDS_EV_IN_RESET                            104
#define DDS_EV_IN_EXIT                             105
#define DDS_EV_IN_CUSTOM_TTS_TEXT                  106
#define DDS_EV_IN_AUDIO_STREAM                     107
#define DDS_EV_IN_PLAYER_STATUS                    108

/* error id */
#define DDS_ERROR_BASE 1000
#define DDS_ERROR_FATAL     (DDS_ERROR_BASE + 1)
#define DDS_ERROR_TIMEOUT   (DDS_ERROR_BASE + 2)
#define DDS_ERROR_NETWORK   (DDS_ERROR_BASE + 3)
#define DDS_ERROR_SERVER    (DDS_ERROR_BASE + 4)  

struct dds_msg;

typedef int (*dds_ev_callback)(void *userdata, struct dds_msg *msg);

struct dds_opt {
	dds_ev_callback _handler;
	void *userdata;
};

int dds_start(struct dds_msg *conf, struct dds_opt *opt);
int dds_send(struct dds_msg *msg);

/* message pack or unpack */
struct dds_msg *dds_msg_new();
int dds_msg_delete(struct dds_msg *msg);
void dds_msg_print(struct dds_msg *msg);

int dds_msg_set_type(struct dds_msg *msg, int value);
int dds_msg_set_integer(struct dds_msg *msg, const char *key, int value);
int dds_msg_set_double(struct dds_msg *msg, const char *key, double value);
int dds_msg_set_boolean(struct dds_msg *msg, const char *key, int value);
int dds_msg_set_string(struct dds_msg *msg, const char *key, const char *value);
int dds_msg_set_bin(struct dds_msg *msg, const char *key, const char *value, int value_len);

int dds_msg_get_type(struct dds_msg *msg, int *value);
int dds_msg_get_integer(struct dds_msg *msg, const char *key, int *value);
int dds_msg_get_double(struct dds_msg *msg, const char *key, double *value);
int dds_msg_get_boolean(struct dds_msg *msg, const char *key, int *value);
int dds_msg_get_string(struct dds_msg *msg, const char *key, char **value);
int dds_msg_get_bin(struct dds_msg *msg, const char *key, char **value, int *value_len);

#endif
